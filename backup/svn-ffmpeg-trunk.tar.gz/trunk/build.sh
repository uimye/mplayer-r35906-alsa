#!/bin/sh
./configure --arch=mips \
--target-os=linux \
--cc=mipsel-linux-gcc \
--enable-cross-compile \
--ar=mipsel-linux-ar \
--sysroot=/opt/toolchain-delete-openwrt/toolchain-mipsel_24kec+dsp_gcc-4.8-linaro_uClibc-0.9.33.2/bin \
--disable-network \
--disable-armv6 \
--disable-armv6t2  \
--enable-gpl \
--enable-swscale \
--enable-postproc \
--enable-gpl \
--enable-pthreads \
--prefix=./build
