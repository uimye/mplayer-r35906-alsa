#ifndef _parser_cfg_h
#define _parser_cfg_h

extern int m_config_parse_config_file(m_config_t* config, char *conffile);

#endif
