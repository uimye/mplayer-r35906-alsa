
#define BUILD_VFWEX 1

#include "vd_vfw.c"
